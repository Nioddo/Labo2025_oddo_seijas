package SitioWeb;

public class CPU {
    private int codCPU;
}
