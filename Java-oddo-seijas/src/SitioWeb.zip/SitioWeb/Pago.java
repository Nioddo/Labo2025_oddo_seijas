package SitioWeb;

public class Pago {
    private double recargo;
    private String numeroTarjeta;
    private String nombreTitular;

}
